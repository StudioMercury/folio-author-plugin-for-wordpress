<?php
/*
Description: iPad article template for the DPS Folio Authoring Plugin.
*/
?>

<h1>No Name Template</h1>
