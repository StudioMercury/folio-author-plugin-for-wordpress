<?php

$config = array(
    'api_server' => 'https://dpsapi2.acrobat.com',
    'company' => '',
    'consumer_key' => '',
    'consumer_secret' => '',
    'email' => '',
    'password' => ''
);
