<?php
/*
Article Template Name: 
Description: iPad article template for the DPS Folio Authoring Plugin.
*/
?>

<h1>iPad Template</h1>
