<div id="dialog" title="Basic modal dialog"></div>

<BR/>
<input type="submit" value="Save Folio" name="publish" id="publish" class="button-secondary" style="width: 45%;margin-right:5%;" accesskey="p">
<a data-action="delete_folio" data-folio="<?php echo $post_id;?>" class="button-secondary" style="background: #d2322d !important; color: #ffffff; text-shadow: none;width: 45%; text-align:center;">Delete Folio</a>
<BR/>
<BR/>