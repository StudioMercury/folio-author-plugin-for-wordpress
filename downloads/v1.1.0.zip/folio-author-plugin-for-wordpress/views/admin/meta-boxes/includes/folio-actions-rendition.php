<BR/>
<div class="medium primary btn"><input type="submit" value="Save Rendition" name="publish" id="publish" accesskey="p"></div>
<div class="medium danger btn"><a data-action="delete_rendition" data-folio="<?php echo $post_id;?>" class="" >Delete</a></div>

<BR/><BR/>