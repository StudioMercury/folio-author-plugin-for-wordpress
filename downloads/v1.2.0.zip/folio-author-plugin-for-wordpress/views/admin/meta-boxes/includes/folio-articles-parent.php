<?php
    $articleService = DPSFolioAuthor_Article::getInstance();
?>

<style>
    #dps_folio_author_folio-articles .hndle, 
    #dps_folio_author_folio-articles .handlediv { display: none; }
    #dps_folio_author_folio-articles { background: none; background-color: none; border: none; padding: 0px; }
    #dps_folio_author_folio-articles .inside { padding: 0px; margin: 0px; }    
</style>

<!--

<hr/>

<div style="text-align:center">
    <h2>Add Articles
        <a onclick="" class="add-new-h2"><i class="icon-plus"></i> ADD an article</a>
    <a onclick="" class="add-new-h2"><i class="icon-bolt"></i> IMPORT articles from SIDECAR.XML</a>
    </h2>
</div>

-->